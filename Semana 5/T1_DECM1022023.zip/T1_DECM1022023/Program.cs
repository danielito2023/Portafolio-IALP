﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_DECM1022023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            
            Console.WriteLine("Indica tu nombre");
            String sNombre = Console.ReadLine();
            Console.WriteLine("Indica tu edad");
            String sEdad = Console.ReadLine();
            Console.WriteLine("Indica tu carrera");
            String sCarrera = Console.ReadLine();
            Console.WriteLine("Indica tu carné");
            String sCarné = Console.ReadLine();

            Console.ReadKey();

            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Nombre:" + sNombre);
            Console.WriteLine("Edad:" + sEdad);
            Console.WriteLine("Carrera:" + sCarrera);
            Console.WriteLine("Carné:" + sCarné);

            Console.ReadKey();

            Console.WriteLine("Hola, soy "+sNombre+", tengo "+sEdad+" años y estudio la carrera de "+sCarrera+". Mi número de carné es: "+sCarné);

            Console.ReadKey();
        }
    }
}
