﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4_DECM1022023E1
{
    internal class Program
    {
        static void Main(string[] args)
        {
                double Vo = 0, Vf = 0, a = 0, T = 0, Desconocida = 0;
                Console.WriteLine("Ingrese el valor de la variable que quiere calcular: Vo = 1, Vf = 2, a = 3 o T = 4");
                Desconocida = Convert.ToDouble(Console.ReadLine());

                if (Desconocida == 1)
                {
                    Console.WriteLine("Ingrese el valor de Vf");
                    Vf = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de a");
                    a = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de T");
                    T = Convert.ToDouble(Console.ReadLine());

                    Desconocida = Vf - a * T;
                    Console.WriteLine("El valor es " + Desconocida);
                }
                else if (Desconocida == 2)
                {
                    Console.WriteLine("Ingrese el valor de Vo");
                    Vo = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de a");
                    a = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de T");
                    T = Convert.ToDouble(Console.ReadLine());

                    Desconocida = Vo + a * T;
                    Console.WriteLine("El valor es " + Desconocida);
                }
                else if (Desconocida == 3)
                {
                    Console.WriteLine("Ingrese el valor de Vf");
                    Vf = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de Vo");
                    Vo = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de T");
                    T = Convert.ToDouble(Console.ReadLine());

                    Desconocida = (Vf - Vo) / T;
                    Console.WriteLine("El valor es " + Desconocida);
                }
                else if (Desconocida == 4)
                {
                    Console.WriteLine("Ingrese el valor de Vf");
                    Vf = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de a");
                    a = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el valor de Vo");
                    Vo = Convert.ToDouble(Console.ReadLine());

                    Desconocida = (Vf - Vo) / a;
                    Console.WriteLine("El valor es " + Desconocida);

                }
                else
                {
                    Console.WriteLine("ERROR");
                }


                Console.ReadKey();
            }
    }
}
