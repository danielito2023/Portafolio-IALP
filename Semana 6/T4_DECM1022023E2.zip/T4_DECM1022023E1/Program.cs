﻿using System;

namespace T4_DECM1022023E1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Cantidad = 0;
            Console.WriteLine("Daniel Estuardo Castellanos Morales - 1022023");
            Console.WriteLine("Ingrese su dinero");
            Cantidad = Convert.ToDouble(Console.ReadLine());
            if (Cantidad < 1000 && Cantidad > 0)
            {
                int billete100 = (int)(Cantidad / 100);
                int billete50 = (int)((Cantidad % 100) / 50);
                int billete20 = (int)(((Cantidad % 100) % 50) / 20);
                int billete10 = (int)((((Cantidad % 100) % 50) % 20) / 10);
                int billete5 = (int)(((((Cantidad % 100) % 50) % 20) % 10) / 5);
                int billete1 = (int)((((((Cantidad % 100) % 50) % 20) % 10) % 5) / 1);

                int centavo50 = (int)(((((((Cantidad % 100) % 50) % 20) % 10) % 5) % 1) / 0.50);
                int centavo25 = (int)((((((((Cantidad % 100) % 50) % 20) % 10) % 5) % 1) % 0.50) / 0.25);
                int centavo1 = (int)(((((((((Cantidad % 100) % 50) % 20) % 10) % 5) % 1) % 0.5) % 0.25) / 0.01);

                Console.WriteLine($"{billete100} de Q100");
                Console.WriteLine($"{billete50} de Q50");
                Console.WriteLine($"{billete20} de Q20");
                Console.WriteLine($"{billete10} de Q10");
                Console.WriteLine($"{billete5} de Q5");
                Console.WriteLine($"{billete1} de Q1");
                Console.WriteLine($"{centavo50} de Q0.5");
                Console.WriteLine($"{centavo25} de Q0.25");
                Console.WriteLine($"{centavo1} de Q0.01");
            }
            else
            {
                Console.WriteLine("ERROR");
            }
            Console.ReadKey();
        }
    }
}
