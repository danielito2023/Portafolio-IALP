﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace T9_DECM_1022023
{
    using System;

    class Motocicleta
    {
        public int Modelo = 2019;
        public double Precio = 1000;
        public string Marca = "";
        public double Iva = 0.12;

        public string MostrarDatos()
        {
            return $"Modelo: {Modelo}, Marca: {Marca}, Precio sin IVA: {Precio}, IVA: {Iva}";
        }

        public void DefinirPrecio(double precio)
        {
            Precio = precio;
        }

        public void DefinirIva(double iva)
        {
            if (iva >= 0.01 && iva <= 0.99)
            {
                Iva = iva;
            }
            else
            {
                Console.WriteLine("\nSe usará el IVA por defecto");
            }
        }

        public double PrecioSinIva()
        {
            return Precio;
        }

        public double PrecioConIva()
        {
            return Precio + (Precio * Iva);
        }

        public double DevolverIva()
        {
            return Precio * Iva;
        }
    }

}
