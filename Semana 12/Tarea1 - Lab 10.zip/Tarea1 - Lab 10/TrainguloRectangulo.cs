﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea1___Lab_10
{
    internal class TrianguloRectangulo
    {
        private double catetoA;
        private double anguloOpuestoA;

        public void SetCatetos(double CatetoA, double AnguloOpuestoA)
        {
            this.catetoA = CatetoA;
            this.anguloOpuestoA = AnguloOpuestoA * (Math.PI / 180);
        }
        public double ObtenerCatetoA() 
        {
            return catetoA;
        }
        public double ObtenerCatetoB()
        {
            return catetoA / Math.Tan(anguloOpuestoA);
        }
        public double ObtenerHipotenusa()
        {
            return catetoA / Math.Sin(anguloOpuestoA);
        }
        public double ObteneranguloOpuestoA()
        {
            return anguloOpuestoA * (180/Math.PI);
        }
        public double ObteneranguloOpuestoB()
        {
            return 90 - ObteneranguloOpuestoA();
        }
        public double ObtenerArea()
        {
            return ((ObtenerCatetoA()) * (ObtenerCatetoB()) / 2);
        }
        public void ObtenerDatos()
        {
            Console.WriteLine("\nEl valor del cateto a es: " + ObtenerCatetoA().ToString("0.000"));
            Console.WriteLine("El valor del cateto b es: " +  ObtenerCatetoB().ToString("0.000"));
            Console.WriteLine("El valor de la hipotenusa es: " + ObtenerHipotenusa().ToString("0.000"));
            Console.WriteLine("El valor del angulo opuesto de a es: " + ObteneranguloOpuestoA().ToString("0.000"));
            Console.WriteLine("El valor del angulo opuesto de b es: " + ObteneranguloOpuestoB().ToString("0.000"));
            Console.WriteLine("El valor del area del triangulo es: " + ObtenerArea().ToString("0.000"));
        }
    }
}
